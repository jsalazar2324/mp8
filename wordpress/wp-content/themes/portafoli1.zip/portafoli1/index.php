<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>" />
	<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/style.css" />
    
    <title>Portfoli</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
    <body>
        <h2>
            <a id="po" href="html/index.html" style="color: #dcddd7;">PO</a>
            <a id="rt" href="html/index.html" style="color:  #dcddd7;">RT</a>
            <br>
            <a id="fo" href="html/index.html" style="color:  #dcddd7;">FO</a>
            <a id="li" href="html/index.html" style="color:  #dcddd7;">LI</a>
        </h2>
        <h1>Júlia Salazar García</h1>
        
    </body>
</html>